﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AnlStageController.Util;
using System.Threading;
using System.Collections;

namespace AnlStageController {
    public partial class FormAlmDynamic : FormManualBase
    {
        // Alm軸動特性測定シーケンス
        private AlmDynamics m_AlmDynamics;
        // laserNo配列
        private List<int> laserNoList;

        //イベントハンドラー
        public event UpdateThreadInfoEvent updateThreadInfoEvent;
        public event CompleteThreadInfoEvent completeThreadInfoEvent;

        private const string Str_Laser = "Laser";
        //private bool seqErrorEndFlg = false;

        // ユーザーコントロールobj<LaserNo, ユーザーコントロール(Alm1～4)>
        private Dictionary<int, List<PanelAlmDynamic>> pnlAlmDynamicList;

        // 選択された軸<レーザーNo, Alm配列>
        private Dictionary<int, List<int>> axisSelected;

        // ラベル
        private string STR_BTNSTS_STOPPING = "停止中...";
        private string STR_BTNSTS_STOP = "測定中止";

        #region コンストラクタ
        public FormAlmDynamic()
        {
            InitializeComponent();
            m_AlmDynamics = new AlmDynamics();
            pnlAlmDynamicList = new Dictionary<int, List<PanelAlmDynamic>>();
            // イベントの追加
            updateThreadInfoEvent += new UpdateThreadInfoEvent(UpdateThreadInfoHandler);
            completeThreadInfoEvent += new CompleteThreadInfoEvent(CompleteThreadInfoHandler);

        }
        #endregion

        /// <summary>
        /// ロードイベント
        /// </summary>
        private void FormAlmDynamic_Load(object sender, EventArgs e)
        {
            Initialization();
            LogEgis.DebugLog("◆Alm軸動特性画面Open");
        }

        /// <summary>
		/// フォームのプロパティ設定
		/// </summary>
        private void Initialization()
        {
            this.Visible = false;

            // レーザー初期化
            laserNoList = new List<int>();
            laserNoList = m_AlmDynamics.getLaserEnableConf();
            // シーケンス初期化
            m_AlmDynamics.Initialize();

            if (laserNoList.Count == 0)
            {
                MessageManager.Show("ERR_GET_AVAILABLE_RASER_FALIED", "Error");
                laserNoList.Add(1);
            }

            // Alm選択用DataGridView初期化
            //this.dataGridAlmSelect.ColumnCount = 1 + Enum.GetNames(typeof(ALM_Axis)).Length;    // LaserNo + ALM1～4
            this.dataGridAlmSelect.ReadOnly = false;
            this.dataGridAlmSelect.RowHeadersVisible = false;
            this.dataGridAlmSelect.AllowUserToResizeColumns = false;
            this.dataGridAlmSelect.AllowUserToResizeRows = false;
            this.dataGridAlmSelect.AllowUserToAddRows = false;
            this.dataGridAlmSelect.MultiSelect = true;      // 複数測定

            // dgv初期化
            this.dataGridAlmSelect.Columns.Add(Str_Laser, Str_Laser);
            foreach (ALM_Axis axis in Enum.GetValues(typeof(ALM_Axis)))
            {
                DataGridViewCheckBoxColumn axisCol = new DataGridViewCheckBoxColumn();
                axisCol.HeaderText = axis.ToString();
                axisCol.ValueType = System.Type.GetType("System.Boolean");
                axisCol.Name = axis.ToString();
				axisCol.Width = 60;
                this.dataGridAlmSelect.Columns.Add(axisCol);
            }

            this.dataGridAlmSelect.RowCount = this.laserNoList.Count;
            BeamIncidentInifile.almSettingParam almSettingParam;
            
            // タブの初期化
            for (int laserIdx = 0; laserIdx < laserNoList.Count; laserIdx++ )
            {
                List<PanelAlmDynamic> lstAlmPnl = new List<PanelAlmDynamic>();
                string strLaserName = Str_Laser + (laserNoList[laserIdx] + 1).ToString();
                if (laserIdx == 0)
                    this.tabLaserSelect.TabPages[0].Text = strLaserName;
                else
                    this.tabLaserSelect.TabPages.Add(strLaserName);

                this.tabLaserSelect.TabPages[laserIdx].BackColor = Color.White;
                m_AlmDynamics.SetLaser(laserNoList[laserIdx]);
                // データグリッドビューレーザー列
                this.dataGridAlmSelect.Rows[laserIdx].Cells[0].Value = strLaserName;
                this.dataGridAlmSelect.Rows[laserIdx].Cells[0].ReadOnly = true;

                // ユーザーコントロールの初期化
                foreach (ALM_Axis axis in Enum.GetValues(typeof(ALM_Axis)))
                { 
                    PanelAlmDynamic pnlAlmDynamic = new PanelAlmDynamic();
                    List<double> measurePointList = m_AlmDynamics.SetAxis((int)axis);
                    lstAlmPnl.Add(pnlAlmDynamic);

                    // 測定点定義入力チェック
                    almSettingParam = m_AlmDynamics.iniFile.laserSettings[laserNoList[laserIdx]].GetAxisParam(axis);
                    if (almSettingParam.numOfPos == 0 || almSettingParam.numOfPos != almSettingParam.measPos.Length)
                    {
                        string strLaserAxis = string.Format("{0}-{1}", Str_Laser + (laserNoList[laserIdx] + 1).ToString(), axis.ToString());
                        MessageManager.Show(MessageManager.GetMsg("ERR_ALM_MEASURE_POINTS_READ_FAILED", strLaserAxis), "Error");
                        this.Close();
                        return;
                    }
                    
                    if (axis != ALM_Axis.ALM1)
                    {
                        pnlAlmDynamic.Location = new Point((int)axis * lstAlmPnl[0].Width);
                    }
                    this.tabLaserSelect.TabPages[laserIdx].Controls.Add(pnlAlmDynamic);

                    pnlAlmDynamic.laserNo = laserNoList[laserIdx];
                    pnlAlmDynamic.almNameLabel = axis.ToString();
                    pnlAlmDynamic.calcResultTextX = string.Empty;
                    pnlAlmDynamic.calcResultTextY = string.Empty;
                    // 測定点の表示
                    pnlAlmDynamic.setMeasureData(measurePointList);

                    // データグリッドビューALM列
                    this.dataGridAlmSelect.Rows[laserIdx].Cells[(int)axis + 1].Value = false;
                }

                pnlAlmDynamicList.Add(laserNoList[laserIdx], lstAlmPnl);
            }
            this.dataGridAlmSelect.RowCount = this.laserNoList.Count;
            this.dataGridAlmSelect.CurrentCell = null;

            this.Visible = true;

            // ユーザーコントロールのカーソルをクリア
            for (int laserIdx = 0; laserIdx < pnlAlmDynamicList.Count; laserIdx++)
            {
                int laserNo = this.laserNoList[laserIdx];
                for (int axisIdx = 0; axisIdx < pnlAlmDynamicList[laserNo].Count; axisIdx++)
                {
                    pnlAlmDynamicList[laserNo][axisIdx].unableCurrentCell();
                }
            }
        }

        /// <summary>
        /// 測定開始ボタン押下イベント
        /// </summary>
        private void buttonMeasureStart_Click(object sender, EventArgs e)
        {
            // 未保存の計算結果を破棄しますか?
            if (!confirmRevocResult())
            {
                return;
            }
            clearAllResult();

            m_AlmDynamics.m_FormManualBase = this;
			
            axisSelected = new Dictionary<int, List<int>>();
            bool getAxisSuccess = getSelectedAlm(axisSelected);
            if (!getAxisSuccess) 
            {
                MessageManager.Show("INFO_SELECT_ALM_AXIS", "Info");
                return;
            }
            EnableDisableControl(false);

            // 測定位置などの設定を読み込む
            int nextLaserNo = this.axisSelected.ElementAt(0).Key;
            int nextAxisNo = this.axisSelected.ElementAt(0).Value[0];
            m_AlmDynamics.SetLaserAxis(nextLaserNo, nextAxisNo);

            //シーケンススレッド起動
            Thread DoFunctionThread = new Thread(new ThreadStart(m_AlmDynamics.DoWork));
            m_AlmDynamics.m_DoFunctionThread = DoFunctionThread;
            DoFunctionThread.Start();
            
        } 

        /// <summary>
        /// 選択状態のalm軸を取得する
        /// </summary>
        private bool getSelectedAlm(Dictionary<int, List<int>> selectedAlm)
        {
            for (int laserIdx = 0; laserIdx < laserNoList.Count; laserIdx++ ) {
                List<int> axisList = new List<int>();
                foreach (int axisNo in Enum.GetValues(typeof(ALM_Axis))) {
                    // 選択されている場合、配列に追加
                    if ((bool)this.dataGridAlmSelect.Rows[laserIdx].Cells[axisNo + 1].Value == true) {
                        axisList.Add(axisNo);
                    }
                }

                if (axisList.Count > 0) {
                    selectedAlm.Add(laserNoList[laserIdx], axisList);
                }
            }

            if (selectedAlm.Count == 0) {
                // 選択中が0件
                return false;
            }
            return true;
           
        }

        /// <summary>
		/// コントロールの有効/無効設定
		/// </summary>
        private void EnableDisableControl(bool sts)
        {
            this.buttonMeasureStart.Enabled = sts;
            this.buttonClose.Enabled = sts;
            this.dataGridAlmSelect.Enabled = sts;
            this.tabLaserSelect.Enabled = sts;
        }

        /// <summary>
        /// 測定中止ボタン押下イベント
        /// </summary>
        private void buttonStop_Click(object sender, EventArgs e)
        {
            if (true == this.buttonMeasureStart.Enabled) 
            {
                // 測定処理実行していない場合、何もしない
                return;
            }

            // 停止ボタンレイアウト変換
            this.buttonStop.Text = STR_BTNSTS_STOPPING;
            this.buttonStop.Enabled = false;
            //基底シーケンスを中止状態にする
            m_AlmDynamics.SequenceCancel();
            m_AlmDynamics.StatStop();	
        }

        /// <summary>
        /// 閉じるボタン押下イベント
        /// </summary>
        private void buttonClose_Click(object sender, EventArgs e)
        {
            // 未保存の計算結果を破棄しますか?
            if (!confirmRevocResult())
            {
                return;
            }

            if (MessageManager.Show(MessageManager.GetMsg("CONFIRMATION_END"), "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Close();
                LogEgis.DebugLog("◆Alm軸動特性画面Close");
            }
        }

        /// <summary>
        /// スレッド情報更新(スレッドからの呼び出しメソッド)
        /// </summary>
        public override void UpdateThreadInfo(ArrayList ResultList)
        {
            // 非同期的にデリゲートを実行
            BeginInvoke(updateThreadInfoEvent, ResultList);
        }

        /// <summary>
        /// スレッド情報最終(スレッドからの呼び出しメソッド)
        /// </summary>
        public override void CompleteThreadInfo(ArrayList ResultList)
        {
            // 非同期的にデリゲートを実行
            BeginInvoke(completeThreadInfoEvent, ResultList);
        }

        /// <summary>
        /// スレッド情報の更新ハンドラ
        /// </summary>
		public override void UpdateThreadInfoHandler(ArrayList ResultList)
		{
			// 測定結果を画面に描画
			try {
				AlmDynamics.UpdateMeasureMsg msg = (AlmDynamics.UpdateMeasureMsg)ResultList[0];
				pnlAlmDynamicList[msg.procLaserNo][msg.procAxisNo].setMeasureData(msg.dblCentroidX, msg.dblCentroidY, msg.pointIndex);

			} catch (Exception ex) {
				LogEgis.ExceptionLog("FormTiltDynamics.UpdateThreadInfoHandler()", ex);
			}
		}

        /// <summary>
        /// スレッド情報の最終更新ハンドラ
        /// </summary>
        public override void CompleteThreadInfoHandler(ArrayList ResultList)
        {
            try
            {
                AlmDynamics.NoticeMeasureMsg msg = (AlmDynamics.NoticeMeasureMsg)ResultList[0];
                pnlAlmDynamicList[msg.procLaserNo][msg.procAxisNo].setMeasureData(msg.calcCoordinatesMsg, msg.dblSlopeXMsg, msg.dblSlopeYMsg);

                if (msg.seqStopFlg)
                {
                    // シーケンス停止ボタン押下
                    this.buttonStop.Text = STR_BTNSTS_STOP;
                    this.buttonStop.Enabled = true;
                    MessageManager.Show("INFO_ALMDYNAMICS_STOP", "Info");
                    EnableDisableControl(true);
                    return;
                }

                if (false == msg.formalEndFlgMsg)
                {
                    if (null == msg.errorMsg)
                        MessageManager.Show("ERR_ALMDYNAMICS_ERROR", "Error");
                    else
                        MessageBox.Show(msg.errorMsg, "Error", MessageBoxButtons.OK);

                    EnableDisableControl(true);
                    return;
                }

                // 処理済の軸・レーザーを選択対象コレクションから消す
                this.axisSelected[msg.procLaserNo].Remove(msg.procAxisNo);
                if (this.axisSelected[msg.procLaserNo].Count == 0) 
                {
                    this.axisSelected.Remove(msg.procLaserNo);
                }

                //if (false == msg.formalEndFlgMsg)
                //{
                //    string message = "";
                //    if (null == msg.errorMsg)
                //        message = "軸動特性測定が異常終了になりました。";
                //    else
                //        message = msg.errorMsg;

                //    if (this.axisSelected.Count > 0) 
                //    {
                //        if (MessageManager.Show(message + " 次の選択軸の測定に進めますか?", "エラー", MessageBoxButtons.YesNo) == DialogResult.No)
                //        {
                //            EnableDisableControl(true);
                //            return;
                //        } 
                //    }
                //    else 
                //    {
                //        MessageBox.Show(message, "エラー", MessageBoxButtons.OK);
                //        EnableDisableControl(true);
                //        return;
                //    }
                //}

                if (this.axisSelected.Count > 0) 
                {
                    // コレクションより次の測定対象を取得する
                    int nextLaserNo = this.axisSelected.ElementAt(0).Key;
                    int nextAxisNo = this.axisSelected.ElementAt(0).Value[0];

                    m_AlmDynamics.SetLaserAxis(nextLaserNo, nextAxisNo);

                    //シーケンススレッド起動
                    Thread DoFunctionThread = new Thread(new ThreadStart(m_AlmDynamics.DoWork));
                    m_AlmDynamics.m_DoFunctionThread = DoFunctionThread;
                    DoFunctionThread.Start();
                    return;
                }

                // フォームを有効にする
                EnableDisableControl(true);
            }
            catch (Exception ex)
            {
                LogEgis.ExceptionLog("FormTiltDynamics.CompleteThreadInfoHandler()", ex);
            }
        } 

        /// <summary>
        /// 未保存情報の確認
        /// </summary>
        private bool confirmRevocResult()
        {
            bool allRegistedFlg = checkAllResultRegist();

            if (!allRegistedFlg) 
            {
                // 保存されていない有効な値がある場合
                if (MessageManager.Show("CONFIRMATION_REVERT_UNSAVED_RESULT", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    return true;
                else
                    return false;
            }
            
            return true;
        }

        /// <summary>
        /// 全ての測定結果の保存状況チェック
        /// </summary>
        private bool checkAllResultRegist()
        {
            for (int laserIdx = 0; laserIdx < pnlAlmDynamicList.Count; laserIdx++)
            {
                int laserNo = this.laserNoList[laserIdx];
                for (int axisIdx = 0; axisIdx < pnlAlmDynamicList[laserNo].Count; axisIdx++)
                {
                    if (!pnlAlmDynamicList[laserNo][axisIdx].resultRegistFlg)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// 測定結果&計算結果を全部クリア
        /// </summary>
        private void clearAllResult()
        {
            // ユーザーコントロールの測定結果&計算結果をクリア
            for (int laserIdx = 0; laserIdx < pnlAlmDynamicList.Count; laserIdx++)
            {
                int laserNo = this.laserNoList[laserIdx];
                for (int axisIdx = 0; axisIdx < pnlAlmDynamicList[laserNo].Count; axisIdx++)
                {
                    pnlAlmDynamicList[laserNo][axisIdx].clearMeasureRows();
                }
            }
        }

    }
}
