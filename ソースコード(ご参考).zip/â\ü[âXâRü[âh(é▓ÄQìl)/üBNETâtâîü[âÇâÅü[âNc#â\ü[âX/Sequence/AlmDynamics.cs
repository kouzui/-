﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Threading;
using System.Collections;
using AnlStageController.Util;

namespace AnlStageController
{
    class AlmDynamics : Sequence
    {
        public DataSet measureDetail;  	    //軸測定情報テーブル
        private double axisInitPos;       //測定前軸位置(mm)
        public double dblSlopeX = double.NaN;           //傾きX
        public double dblSlopeY = double.NaN;           //傾きY
        private bool _bAlmIni = true;              //開始時位置へ戻す処理の有効フラグ(true時事項)
        private ProfilerDataReader profilerDataReader;

        private double[,] calcCoordinates;      // 傾き計算用座標

        private ALM_Axis almAxisSelected;
        private int laserSelected = -1;
        public bool formalEndFlgMsg = true;       // 全測定点測定完了フラグ(正常完了フラグ)
		public bool axisMoveOkFlg = false;		  // 軸移動フラグ(正常完了フラグ)

        // 画面へ通知用(完了)
        public class NoticeMeasureMsg
        {
            public bool formalEndFlgMsg;       // 全測定点測定完了フラグ(正常完了フラグ)
            public double dblSlopeXMsg = double.NaN;         // 傾きX
            public double dblSlopeYMsg = double.NaN;         // 傾きY
            public double[,] calcCoordinatesMsg;       // 座標配列
            public int procLaserNo;            // 処理対象レーザーのlaserNo
            public int procAxisNo;             // 処理対象軸の軸No
            public bool seqStopFlg;            // シーケンス停止フラグ(ボタンより)
			public string errorMsg = null;			   // エラーメッセージ
        }

        // 画面へ通知用(更新)
        public class UpdateMeasureMsg
        {
            public int pointIndex = 0;                      // 点のインデックス
            public double dblCentroidX = double.NaN;        // 測定結果X
            public double dblCentroidY = double.NaN;        // 測定結果Y
            public int procLaserNo;            // 処理対象レーザーのlaserNo
            public int procAxisNo;             // 処理対象軸の軸No
        }

        // ファイルクラス
        public BeamIncidentInifile iniFile;
        public BeamReferencePrm prmFile;

		public string errMsg = null;

		private readonly int HeadNo = 2;

		//暫定
		private bool IsAveEnable = true;

        /// <summary>
        /// コンストラクタ
        /// <summary>
        public AlmDynamics()
        {
            // クラス生成
            measureDetail = new DataSet();
            try 
            {
                iniFile = new BeamIncidentInifile();
                prmFile = new BeamReferencePrm();
            }
            catch(Exception ex)
            {
                LogEgis.ExceptionLog("AlmDynamics.AlmDynamics()", ex);
            }
        }

        /// <summary>
        /// コンストラクタ
        /// <summary>
        public AlmDynamics(int laserNo)
        {
            // クラス生成
            measureDetail = new DataSet();
            try
            {
                iniFile = new BeamIncidentInifile();
                prmFile = new BeamReferencePrm();
            }
            catch (Exception ex)
            {
                LogEgis.ExceptionLog("AlmDynamics.AlmDynamics(int laserNo)", ex);
            }
            this.laserSelected = laserNo;
        }

        /// <summary>
        /// 初期化
        /// </summary>
        public override bool Initialize()
        {
            bool isOk = false;

            try
            {

                LogEgis.AllLog("▼ALM軸動特性_測定シーケンス初期化開始");
                List<int> laserNoList = new List<int>();
                laserNoList = getLaserEnableConf();
                // AlmDynamics(int laserNo)で呼び出した場合はセットしない
                if (this.laserSelected == -1) this.laserSelected = laserNoList[0];

                // ProfilerDataReaderの生成&初期化
                profilerDataReader = new ProfilerDataReader(this.laserSelected);
                isOk = profilerDataReader.Initialize();
                if (false == isOk)
                {
                    LogEgis.DebugLog("プロファイラ読み込みクラス 初期化失敗");
                    LogEgis.AllLog("▲ALM軸動特性_測定シーケンス初期化 NG");
                    return isOk;
                }

                // 設定ファイル読み込み
                isOk = iniFile.ReadIni();
                ReadSettingFile(this.laserSelected);
                if (false == isOk)
                {
                    LogEgis.DebugLog("iniファイル読み込み失敗");
                    LogEgis.AllLog("▲ALM軸動特性_測定シーケンス初期化 NG");
                    return isOk;
                }
            }
            catch(IndexOutOfRangeException ex)
            {
                LogEgis.ExceptionLog("有効中のLaserNo取得失敗", ex);
                LogEgis.AllLog("▲ALM軸動特性_測定シーケンス初期化 NG");
                return false;
            }
            catch (Exception ex)
            {
                LogEgis.ExceptionLog("AlmDynamics.Initialize()", ex);
                LogEgis.AllLog("▲ALM軸動特性_測定シーケンス初期化 NG");
                return false;
            }
            return true;
        }

        /// <summary>
        /// AML軸動特性の実施
        /// </summary>
        protected override void DoFunction()
        {
			bool isOk = false;
			
			isOk = Preparation();
			if (false == isOk) {
				LogEgis.AllLog("シーケンス開始前の事前処理失敗");
				return;
			}

            LogEgis.AllLog("▼ALM軸動特性_測定シーケンスの開始");
            DoFunctionStart();
            LogEgis.AllLog("▲ALM軸動特性_測定シーケンスの終了");	

            DoFinal();
        }

        /// <summary>
        /// シーケンス開始前の事前処理
        /// </summary>
		new public bool Preparation()
        {
			this.errMsg = null;
			this.formalEndFlgMsg = true;
            this.axisMoveOkFlg = false;
            this.dblSlopeX = double.NaN;
            this.dblSlopeY = double.NaN;
            // 傾き計算用構造体処初期化
            int measurePointCount = measureDetail.Tables[almAxisSelected.ToString()].Rows.Count;      // 選択中軸の測定点数
			if (1 >= measurePointCount) 
			{
                this.errMsg = MessageManager.GetMsg("ERR_ALM_MEASURE_POINTS_LESS_THAN_TWO", this.almAxisSelected.ToString());
				LogEgis.DebugLog(errMsg);
				this.formalEndFlgMsg = false;
				return false;
			}
            calcCoordinates = new double[measurePointCount, 3]; DataRow rsdow = measureDetail.Tables[almAxisSelected.ToString()].Rows[0];
            // 測定点初期化
            for (int pointIdx = 0; pointIdx < measurePointCount; pointIdx++ )
            {
                DataRow row = measureDetail.Tables[almAxisSelected.ToString()].Rows[pointIdx];
                double measuringPos;
                bool isOk = double.TryParse(row["measurePos"].ToString(), out measuringPos);
                if (false == isOk)
                {
                    this.errMsg = MessageManager.GetMsg("ERR_ALM_MEASURE_POINTS_READ_FAILED", this.almAxisSelected.ToString());
                    LogEgis.DebugLog(errMsg);
                    this.formalEndFlgMsg = false;
                    return false;
                }
                calcCoordinates[pointIdx, 0] = measuringPos;
                calcCoordinates[pointIdx, 1] = double.NaN;
                calcCoordinates[pointIdx, 2] = double.NaN;
            }
            LogEgis.AllLog("▲ALM軸動特性_測定シーケンス初期化 OK");

			return true;
        }

        /// <summary>
        /// ミラー軸動特性の測定
        /// </summary>
        private void DoFunctionStart()
        {
            _bSeqStop = false;
			bool isOk = false;
            //イベント用引数
            ArrayList resultList = new ArrayList();
            try
            {
                // 停止指令を確認
                if (_bSeqStop)
                {
                    LogEgis.AllLog("▲ALM軸動特性_停止ボタン押下で測定シーケンス終了");
                    this.formalEndFlgMsg = false;
                    return;
                }
                
                BeamIncidentInifile.laserSettingParam laserParam = this.iniFile.laserSettings[this.laserSelected];

                // 測定開始前の軸位置を取得
				isOk = ReadCurrentAxisPosition(this.almAxisSelected);
				if (false == isOk) {
                    this.errMsg = MessageManager.GetMsg("ERR_ALM_AXIS_POSITION_READ_FAILED", this.almAxisSelected.ToString());
					LogEgis.DebugLog(errMsg);
					this.formalEndFlgMsg = false;
                    return;
				}

                int rowIndex = 0;
                //測定位置点数分でループ
                foreach (DataRow row in measureDetail.Tables[almAxisSelected.ToString()].Rows)
                {
                    double measuringPos = this.calcCoordinates[rowIndex, 0];

                    // 軸移動指令
					axisMoveOkFlg = MoveAxis2Position(measuringPos, this.almAxisSelected);
					if (false == axisMoveOkFlg) 
					{
                        this.errMsg = MessageManager.GetMsg("ERR_ALM_AXIS_MOVE_FAILED", this.almAxisSelected.ToString());
						LogEgis.DebugLog(errMsg);
						this.formalEndFlgMsg = false;
						return;
					}

					int bufferSize = this.iniFile.laserSettings[this.laserSelected].BufferSize;
					int cutCount = this.iniFile.laserSettings[this.laserSelected].CutCount;

					isOk = profilerDataReader.MeasStart(this.laserSelected, this.HeadNo, laserParam.ShotCount, laserParam.ShotFreq, laserParam.ProfilerGetDataDelay, bufferSize, cutCount);
					if (false == isOk) {
                        if (null == profilerDataReader.Result)
                            this.errMsg = MessageManager.GetMsg("ERR_ALM_DYNAMICS_PROFILER_READ_FAILED", this.almAxisSelected.ToString());
                        else
                            this.errMsg = MessageManager.GetMsg("ERR_ALM_DYNAMICS_RASER_SHOT_FAILED", this.almAxisSelected.ToString());

						LogEgis.DebugLog(this.errMsg);
						this.formalEndFlgMsg = false;
						return;
					}

                    if (this.almAxisSelected == ALM_Axis.ALM1 || this.almAxisSelected == ALM_Axis.ALM4)
                    {
						if (IsAveEnable) {
							row["centroidX"] = profilerDataReader.DataAve[1, 0];
							row["centroidY"] = profilerDataReader.DataAve[1, 1];
						} else {
							row["centroidX"] = profilerDataReader.DataMedian[1, 0];
							row["centroidY"] = profilerDataReader.DataMedian[1, 1];
						}

                        // ALM1の場合はangleX、ALM4の場合はangleYをセット
                        //calcCoordinates[rowIndex, 1] = (this.almAxisSelected == ALM_Axis.ALM1) ? profilerDataReader.DataAve[1, 0]:
                        //                                                    profilerDataReader.DataAve[1, 1]; 
						if (IsAveEnable) {
							calcCoordinates[rowIndex, 1] = profilerDataReader.DataAve[1, 0];
							calcCoordinates[rowIndex, 2] = profilerDataReader.DataAve[1, 1];
						} else {
							calcCoordinates[rowIndex, 1] = profilerDataReader.DataMedian[1, 0];
							calcCoordinates[rowIndex, 2] = profilerDataReader.DataMedian[1, 1];
						}

                    }
                    else if (this.almAxisSelected == ALM_Axis.ALM2 || this.almAxisSelected == ALM_Axis.ALM3)
                    {
						if (IsAveEnable) {
							row["centroidX"] = profilerDataReader.DataAve[0, 0];
							row["centroidY"] = profilerDataReader.DataAve[0, 1];
						} else {
							row["centroidX"] = profilerDataReader.DataMedian[0, 0];
							row["centroidY"] = profilerDataReader.DataMedian[0, 1];
						}

                        // ALM2の場合はangleX、ALM3の場合はangleYをセット
                        //calcCoordinates[rowIndex, 1] = (this.almAxisSelected == ALM_Axis.ALM2) ? profilerDataReader.DataAve[2, 0]:
                        //                                                    profilerDataReader.DataAve[2, 0];
						if (IsAveEnable) {
							calcCoordinates[rowIndex, 1] = profilerDataReader.DataAve[0, 0];
							calcCoordinates[rowIndex, 2] = profilerDataReader.DataAve[0, 1];
						} else {
							calcCoordinates[rowIndex, 1] = profilerDataReader.DataMedian[0, 0];
							calcCoordinates[rowIndex, 2] = profilerDataReader.DataMedian[0, 1];
						}
					}
                    else 
                    {
                        this.errMsg = MessageManager.GetMsg("ERR_ALM_AXIS_NAME_INVALID");
						LogEgis.DebugLog(this.errMsg);
						this.formalEndFlgMsg = false;
                        return;
                    }
                    resultList.Clear();
                    UpdateMeasureMsg msg = new UpdateMeasureMsg();
                    msg.dblCentroidX = calcCoordinates[rowIndex, 1];
                    msg.dblCentroidY = calcCoordinates[rowIndex, 2];
                    msg.pointIndex = rowIndex;
                    msg.procAxisNo = (int)this.almAxisSelected;
                    msg.procLaserNo = this.laserSelected;
					resultList.Add(msg);

                    // 画面へ出力
                    m_FormManualBase.UpdateThreadInfo(resultList);
                    rowIndex++;

                    // 停止指令を確認
                    if (_bSeqStop)
                    {
						this.m_nSequenceState = 0;
                        LogEgis.AllLog("▲ALM軸動特性_停止ボタン押下で測定シーケンス終了");
                        this.formalEndFlgMsg = false;
                        return;
                    }
                }

                // 傾きを計算する
                isOk = CalcResult(calcCoordinates, ref this.dblSlopeX, ref this.dblSlopeY);
                if (false == isOk) 
                {
                    this.errMsg = MessageManager.GetMsg("ERR_ALM_SLOPE_CALC_ERROR", this.almAxisSelected.ToString());
					this.formalEndFlgMsg = false;
                }
            }
            catch (Exception ex)
            {
				this.errMsg = MessageManager.GetMsg("ERR_ALMDYNAMICS_ERROR");
                LogEgis.ExceptionLog("AlmDynamics.DoFunction()", ex);
                this.formalEndFlgMsg = false;
                return;
            }

        }

        /// <summary>
		/// シーケンス終了
		/// </summary>
        protected override void DoFinal()
        {
            // 軸を開始前位置に戻す
			if (true == axisMoveOkFlg) {
				MoveAxis2LastPosition();
			}

            // シーケンス終了通知メッセージをセットアップ
            ArrayList resultList = new ArrayList();
            NoticeMeasureMsg msg = new NoticeMeasureMsg();
            msg.dblSlopeXMsg = this.dblSlopeX;
            msg.dblSlopeYMsg = this.dblSlopeY;
            msg.calcCoordinatesMsg = this.calcCoordinates;
            msg.formalEndFlgMsg = this.formalEndFlgMsg;
            msg.procAxisNo = (int)this.almAxisSelected;
            msg.procLaserNo = this.laserSelected;
            msg.seqStopFlg = _bSeqStop;
            msg.errorMsg = this.errMsg;


            resultList.Add(msg);
            m_FormManualBase.CompleteThreadInfo(resultList);

        }

        /// <summary>
        /// 軸動特性計算
        /// </summary>
        private bool CalcResult(double[,] coordinates, ref double dblSlopeX, ref double dblSlopeY)
        {
            double dblX2 = 0;   // x2の和
            double dblX = 0;    // xの和
            double dblY = 0;    // yの和
            double dblXY = 0;   // xyの和

            ////////////////////////////
            //最小二乗法
            ////////////////////////////
            try 
            {
                int measurePointCnt = coordinates.GetLength(0);
                int digits = 4;         // 四捨五入桁数
				double devide = 0.0;
                dblSlopeX = double.NaN;
                
                for (int i = 0; i < measurePointCnt; i++)
                {
                    //係数計算
                    dblX2 += Math.Pow(coordinates[i, 0], 2);
                    dblXY += coordinates[i, 0] * coordinates[i, 1];
                    dblX += coordinates[i, 0];
                    dblY += coordinates[i, 1];
                }

                // 傾きX
				devide = (measurePointCnt * dblX2) - (dblX * dblX);
				if (0.0 == devide) {
					dblSlopeX = 0.0;
				} else 
				{
					dblSlopeX = ((measurePointCnt * dblXY) - (dblX * dblY)) / devide;
                    //小数点以下第4位まで四捨五入する。
                    double dblCoef = Math.Pow(10, digits);
                    dblSlopeX = dblSlopeX > 0 ? Math.Floor((dblSlopeX * dblCoef) + 0.5) / dblCoef : Math.Ceiling((dblSlopeX * dblCoef) - 0.5) / dblCoef;
				}
                // 切片は計算しない
                //dblSegment = ((dblX2 * dblY) - (dblXY * dblX)) / ((measurePointCnt * dblX2) - (dblX * dblX));

                dblX2 = 0;   // x2の和
                dblX = 0;    // xの和
                dblY = 0;    // yの和
                dblXY = 0;   // xyの和

                dblSlopeY = double.NaN;

                for (int i = 0; i < measurePointCnt; i++)
                {
                    //係数計算
                    dblX2 += Math.Pow(coordinates[i, 0], 2);
                    dblXY += coordinates[i, 0] * coordinates[i, 2];
                    dblX += coordinates[i, 0];
                    dblY += coordinates[i, 2];
                }

                // 傾きY
				devide = (measurePointCnt * dblX2) - (dblX * dblX);
				if (0.0 == devide) {
					dblSlopeY = 0.0;
				} else {
					dblSlopeY = ((measurePointCnt * dblXY) - (dblX * dblY)) / devide;
                    //小数点以下第4位まで四捨五入する。
                    double dblCoef = Math.Pow(10, digits);
                    dblSlopeY = dblSlopeY > 0 ? Math.Floor((dblSlopeY * dblCoef) + 0.5) / dblCoef : Math.Ceiling((dblSlopeY * dblCoef) - 0.5) / dblCoef;
				}
            }
            catch (Exception ex)
            {
                LogEgis.ExceptionLog("AlmDynamics.CalcResult()", ex);
                return false;
            }
            
            return true;
        }

        /// <summary>
        /// 設定ファイルの読み込み(ファイルクラスのメンバー変数から読む)
        /// </summary>
        /// <param name="laserNo"></param>
        private void ReadSettingFile(int laserNo)
        {
            try
            {
                BeamIncidentInifile.laserSettingParam laserParam = this.iniFile.laserSettings[laserNo];
                foreach (ALM_Axis axisNo in Enum.GetValues(typeof(ALM_Axis)))
                {
                    DataTable axisDataTable = new DataTable(axisNo.ToString());
                    // 測定情報初期化
					axisDataTable.Columns.Add("measurePos", Type.GetType("System.Double"));
                    axisDataTable.Columns.Add("centroidX", Type.GetType("System.Double"));
                    axisDataTable.Columns.Add("centroidY", Type.GetType("System.Double"));

                    // 測定位置をファイルクラスから取得
                    BeamIncidentInifile.almSettingParam almSettingParam = laserParam.GetAxisParam(axisNo);
                    int measurePointCnt = almSettingParam.numOfPos;
                    for (int i = 0; i < measurePointCnt; i++)
                    {
                        axisDataTable.Rows.Add(almSettingParam.measPos[i],
                                            double.NaN,  
                                            double.NaN
                                            );
                    }
                    measureDetail.Tables.Add(axisDataTable);
                }

                
            }
            catch (Exception ex)
            {
                LogEgis.ExceptionLog(ex.Message);
                MessageBox.Show("ALM軸動特性_測定シーケンス初期化が失敗しました");
                return;
            }
        }

        /// <summary>
        /// 傾きを書き込む
        /// </summary>
        /// <param name="laserNo">レーザーNo</param>
        /// <param name="axisNo">ALM軸No</param>
        public bool RegisterAxisSlopeData(int laserNo, ALM_Axis axisNo, double dblSlope)
        {
            try
            {
                //パラメータ書き込み
                bool isOk = true;
                isOk = prmFile.WriteAxisDataSlope(laserNo, axisNo, dblSlope, 0.0);
                if (false == isOk)
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                LogEgis.ExceptionLog(ex.Message);
                return false;
            }

            return true;
        }

        /// <summary>
        /// ALM軸現在位置取得 BeamIncidentAdjustから移植
        /// </summary>
        public bool ReadCurrentAxisPosition(ALM_Axis almAxis)
        {
            try {

				string tag = string.Format("ReadL{0}{1}Data1", this.laserSelected + 1, almAxis.ToString());
                m_command = new Command();
				m_command.ReadElement(tag, true);
                string strRet = SendInterface(m_command, (int)SelectInterface.PLC);

                if (strRet != null)
                {
                    LogEgis.DebugLog("ALM軸現在位置取得失敗");
                    return false;
                }

				axisInitPos = ((double)m_command.ReadData[tag]) / 1000;
            }
            catch (Exception ex) {
                LogEgis.ExceptionLog("AlmDynamics.ReadCurrentAxisPosition()", ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// 選択軸を測定開始前の位置に戻す
        /// </summary>
        public bool MoveAxis2LastPosition()
        {
            if (_bAlmIni)
            {
                return MoveAxis2Position(axisInitPos, this.almAxisSelected);
            }

            return true;
        }

        /// <summary>
        /// 軸移動コマンド送信  BeamIncidentAdjustから移植
        /// </summary>
        /// <param name="dblAbsolutePos">軸移動絶対位置</param>
        public bool MoveAxis2Position(double dblAbsolutePos, ALM_Axis almAxis)
        {
            try {
                BeamIncidentInifile.laserSettingParam laserParam = this.iniFile.laserSettings[this.laserSelected];
                BeamIncidentInifile.almSettingParam almSettingParam = laserParam.GetAxisParam(almAxis);
                double measSpeed = almSettingParam.measSpeed;
                MotorCtrlAbsolute motorCtrlSeq = new MotorCtrlAbsolute();
				motorCtrlSeq.m_axis = string.Format("L{0}{1}", this.laserSelected+1, almAxis.ToString());
                motorCtrlSeq.m_absSpd = (decimal)measSpeed;

                motorCtrlSeq.m_absPos = (decimal)(dblAbsolutePos);
                motorCtrlSeq.DoWork();
                if (false == motorCtrlSeq.m_cmpFlg)
                {
                    return false;
                }
            }
            catch(Exception ex){
                LogEgis.ExceptionLog("AlmDynamics.MoveAxis2Position()", ex);
                return false;
            }
            
            return true;
        }

        /// <summary>
        /// Laser切り替えのデータ設定
        /// </summary>
        /// <param name="laserNo">レーザーNo</param>
        public void SetLaser(int laserNo)
        {
            if (laserNo == this.laserSelected) 
            {
                return;         // 同じレーザーの場合は処理不要
            }
            this.laserSelected = laserNo;
            this.almAxisSelected = ALM_Axis.ALM1;      // レーザー切り替え時画面選択軸をAlm1に戻すと想定

            if (measureDetail != null)
            {
                // 測定情報をリセット
                measureDetail.Reset();
            }
            // 測定情報情報を再読み込み
            ReadSettingFile(laserNo);

        }

        /// <summary>
        /// ALM軸切り替えのデータ設定
        /// </summary>
        /// <param name="axisNo">alm軸No</param>
        public List<double> SetAxis(int axisNo)
        {
            ALM_Axis almAxis = (ALM_Axis)Enum.ToObject(typeof(ALM_Axis), axisNo);
            DataTable axisData = measureDetail.Tables[almAxis.ToString()];
            // 選択軸の測定位置配列、画面表示用
            List<double> measPosList = new List<double>();

            this.almAxisSelected = almAxis;

            foreach (DataRow row in axisData.Rows)
            {
                measPosList.Add((System.Double)row["measurePos"]);
            }

            return measPosList;
        }

        /// <summary>
        /// レーザーNo、axis軸データー設定
        /// </summary>
        /// param name="laserNo">レーザーNo</param>
        /// <param name="axisNo">alm軸No</param>
        public List<double> SetLaserAxis(int laserNo, int axisNo)
        {
            SetLaser(laserNo);
            return SetAxis(axisNo);
        }

        /// <summary>
        /// 有効になっているレーザーNoを取得
        /// </summary>
        /// <returns>laserNoList:レーザーNoの配列</returns>
        public List<int> getLaserEnableConf()
        {
            List<int> laserNoList = new List<int>();
            int laserCount = CAnlStgCtrl.ConfigManager.m_stage.LASER_USAGE.nNUM_OF_LASER;
            for (int laserNum = 0; laserNum < laserCount; laserNum++)
            {
                // 有効の場合配列に追加
                if (true == CAnlStgCtrl.ConfigManager.m_stage.LASER_USAGE.LASER_UNIT[laserNum].bIMPLEMENT_EN) laserNoList.Add(laserNum);
            }

            return laserNoList;
        }
    }
}
