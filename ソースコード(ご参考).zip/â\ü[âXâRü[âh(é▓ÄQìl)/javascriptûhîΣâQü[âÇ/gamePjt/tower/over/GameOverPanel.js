// GameOverPanel の開始
function gop_start()
{
	// キャンバスのクリア
	mp.ctx.clearRect(0, 0, mp.canvas.width, mp.canvas.height);
	// タイトルの表示
	mp.ctx.font = "40px 'ＭＳ ゴシック'";
	mp.ctx.textBaseline = "middle";
	mp.ctx.textAlign = "center";
	mp.ctx.fillStyle = "rgb(0, 0, 0)";
	mp.ctx.fillText("Game Over!", mp.canvas.width/2, mp.canvas.height/2);
	// ボタンの表示制御
	document.getElementById('method').style.display = "none";
	document.getElementById('map').style.display = "none";
	document.getElementById('start').innerHTML = "もう一度";
	document.getElementById('start').style.display = "";
	document.getElementById('first').innerHTML = "スタート画面";
	document.getElementById('first').style.display = "";
	document.getElementById('finish').style.display = "";
	document.getElementById('i_set').style.display = "none";
}
